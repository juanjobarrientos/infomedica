package com.infomed.infomed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfomedApplicationTests {

	@Test
	void contextLoads() {
	}

}
